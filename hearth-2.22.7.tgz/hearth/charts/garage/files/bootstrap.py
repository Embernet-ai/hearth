"""Bootstrap a Garage cluster with the official garage CLI, over RPC.

Runs as a Helm post-install and post-upgrade hook. Upstream's chart leaves the
cluster layout to be done by hand; this does it, then creates the buckets and
access keys the release declares. Every step reads the current state first and
only writes what differs, so a second run changes nothing.

How it reaches Garage: the garage binary from the release's own pinned image
(copied in by the Job's init containers) connects to one node over RPC, with
the release's RPC secret in GARAGE_RPC_SECRET (from the environment, never the
command line) and that node's full id and address in GARAGE_RPC_HOST. There is
no admin token anywhere; the RPC secret is what the nodes already share.

Node ids and addresses come from the GarageNode objects Garage's Kubernetes
discovery writes into the namespace, read with the Job's ServiceAccount (get
and list on garagenodes.deuxfleurs.fr, nothing else). The fetch is
fetch_garage_nodes() and the parsing is garage_nodes(), so a test can feed
GarageNode-shaped JSON without a cluster.

Writes use the CLI's own commands: layout assign, layout apply, bucket create,
bucket allow, bucket deny. Reads use `garage json-api` (the same admin API
calls, proxied over RPC, as JSON) so reruns compare structured state rather
than parse tables. Importing a key also goes through `garage json-api
ImportKey -` with the payload on stdin, because `garage key import` takes the
S3 secret key as a command-line argument, and secrets stay off argv.

What it will never do: remove a node from the layout, delete a bucket, delete
a key, or print a secret.

Python standard library only. Commands and flags are those of the v2.4.1
binary's --help.
"""
import json
import os
import re
import ssl
import subprocess
import sys
import time
import urllib.parse
import urllib.request

CONFIG_PATH = "/opt/bootstrap/config.json"
KEYS_DIR = "/var/run/garage-keys"
GARAGE = "/opt/garage-bin/garage"
SA_DIR = "/var/run/secrets/kubernetes.io/serviceaccount"

CFG = json.load(open(CONFIG_PATH, encoding="utf-8"))
DEADLINE = time.monotonic() + int(CFG["timeoutSeconds"])
RPC_HOST = None  # "<full node id>@<ip>:<port>" of the node the CLI talks to


def log(msg):
    print(msg, flush=True)


def die(msg):
    log("FAILED: " + msg)
    sys.exit(1)


class CliError(Exception):
    pass


def garage(*args, payload=None, host=None):
    """Run the garage CLI against one node. Returns stdout. The RPC secret is
    inherited from this process's environment; nothing secret is in args."""
    env = dict(os.environ)
    env["GARAGE_RPC_HOST"] = host or RPC_HOST
    env.setdefault("RUST_LOG", "error")
    try:
        p = subprocess.run([GARAGE] + list(args), input=payload, capture_output=True,
                           text=True, env=env, timeout=30)
    except subprocess.TimeoutExpired:
        raise CliError("garage %s timed out after 30s" % " ".join(args[:2])) from None
    if p.returncode != 0:
        raise CliError((p.stderr or p.stdout).strip()[-600:])
    return p.stdout


def api(endpoint, body=None, host=None):
    """garage json-api <endpoint> -, payload on stdin, JSON back."""
    out = garage("json-api", endpoint, "-", payload=json.dumps(body), host=host)
    return json.loads(out) if out.strip() else None


def until(what, fn, every=5):
    """Retry fn until it returns something truthy or the deadline passes.
    A node that is still starting refuses connections; that is retried."""
    last = None
    said = 0.0
    while True:
        try:
            out = fn()
            if out:
                return out
            last = "not yet"
        except (CliError, OSError, ValueError, subprocess.TimeoutExpired) as e:
            last = str(e).splitlines()[-1] if str(e) else type(e).__name__
        now = time.monotonic()
        if now >= DEADLINE:
            die("gave up waiting for %s after %ss (last: %s)" % (what, CFG["timeoutSeconds"], last))
        if now - said >= 30:
            log("waiting for %s (%s)" % (what, last))
            said = now
        time.sleep(every)


QUANTITY_RE = re.compile(r"^\s*(\d+(?:\.\d+)?)\s*([KMGTPE]i?|k)?\s*$")
QUANTITY_MULT = {
    None: 1, "k": 10**3, "K": 10**3, "M": 10**6, "G": 10**9, "T": 10**12, "P": 10**15, "E": 10**18,
    "Ki": 2**10, "Mi": 2**20, "Gi": 2**30, "Ti": 2**40, "Pi": 2**50, "Ei": 2**60,
}


def to_bytes(q):
    m = QUANTITY_RE.match(str(q))
    if not m:
        die("capacity %r is not a Kubernetes quantity or a byte count" % q)
    return int(float(m.group(1)) * QUANTITY_MULT[m.group(2)])


# --- 1. Nodes, from the GarageNode objects --------------------------------------

def fetch_garage_nodes():
    """The GarageNodeList for this release, from the Kubernetes API."""
    token = open(os.path.join(SA_DIR, "token"), encoding="utf-8").read().strip()
    ctx = ssl.create_default_context(cafile=os.path.join(SA_DIR, "ca.crt"))
    host = os.environ["KUBERNETES_SERVICE_HOST"]
    port = os.environ.get("KUBERNETES_SERVICE_PORT", "443")
    if ":" in host:
        host = "[%s]" % host
    sel = urllib.parse.quote("garage.deuxfleurs.fr/service=%s" % CFG["fullname"])
    url = "https://%s:%s/apis/deuxfleurs.fr/v1/namespaces/%s/garagenodes?labelSelector=%s" % (
        host, port, CFG["namespace"], sel)
    req = urllib.request.Request(url, headers={"Authorization": "Bearer " + token})
    with urllib.request.urlopen(req, context=ctx, timeout=20) as resp:
        return json.load(resp)


def garage_nodes(node_list):
    """{hostname: [(node_id, "ip:port"), ...]} from a GarageNodeList. A pod
    that lost its volumes comes back with a new id under the same hostname, so
    a hostname can have more than one entry."""
    out = {}
    for item in node_list.get("items", []):
        spec = item.get("spec") or {}
        node_id = (item.get("metadata") or {}).get("name", "")
        if not re.fullmatch(r"[0-9a-f]{64}", node_id) or not spec.get("address"):
            continue
        addr = spec["address"]
        if ":" in addr:
            addr = "[%s]" % addr
        out.setdefault(spec.get("hostname", ""), []).append((node_id, "%s:%s" % (addr, spec["port"])))
    return out


def live(node_id, addr):
    """True when the node answering at addr really is node_id. The CLI's
    connection is a handshake against that public key, so a GarageNode object
    left behind by a pod that lost its volumes (old id, maybe an address that
    now belongs to someone else) never passes."""
    try:
        api("GetClusterStatus", host="%s@%s" % (node_id, addr))
        return True
    except CliError:
        return False


def wait_for_nodes():
    """Find the node each pod <fullname>-<n> runs now, and wait until all of
    them are up and see each other. Returns [{"ordinal", "id", "hostname"}]."""
    global RPC_HOST
    n = int(CFG["nodes"])
    hostnames = ["%s-%d" % (CFG["fullname"], i) for i in range(n)]

    def connected():
        global RPC_HOST
        found = garage_nodes(fetch_garage_nodes())
        current = {}
        for h in hostnames:
            for node_id, addr in found.get(h, []):
                if live(node_id, addr):
                    current[h] = (node_id, addr)
                    break
        missing = [h for h in hostnames if h not in current]
        if missing:
            raise CliError("no live node yet for %s" % ", ".join(missing))
        if RPC_HOST is None:
            node_id, addr = current[hostnames[0]]
            RPC_HOST = "%s@%s" % (node_id, addr)
            log("talking to node %s (%s) over RPC" % (node_id[:16], addr))
        status = api("GetClusterStatus")
        up = {x["id"] for x in status.get("nodes", []) if x.get("isUp")}
        apart = [h for h in hostnames if current[h][0] not in up]
        if not apart:
            return [{"ordinal": i, "hostname": h, "id": current[h][0]} for i, h in enumerate(hostnames)]
        # Kubernetes discovery normally connects peers on its own. Connecting
        # the missing ones explicitly does not depend on it.
        for h in apart:
            try:
                garage("node", "connect", "%s@%s" % current[h])
            except CliError:
                pass
        return None

    nodes = until("all %d node(s) to be up and connected" % n, connected)
    for x in nodes:
        log("node %d is %s" % (x["ordinal"], x["id"][:16]))
    log("all %d node(s) are up and connected" % n)
    return nodes


# --- 2. Layout --------------------------------------------------------------------

def ensure_layout(nodes):
    lay = CFG["layout"]
    capacity = to_bytes(lay["capacity"])
    zone = lay["zone"]
    tags = sorted(lay.get("tags") or [])

    layout = api("GetClusterLayout")
    current = {r["id"]: r for r in layout.get("roles", [])}
    changed = []
    for x in nodes:
        r = current.get(x["id"])
        # `layout assign` without -t keeps a node's tags, so tags only count
        # when values declare some.
        if (r and r.get("zone") == zone and r.get("capacity") == capacity
                and (not tags or sorted(r.get("tags") or []) == tags)):
            continue
        args = ["layout", "assign", "-z", zone, "-c", "%dB" % capacity]
        for t in tags:
            args += ["-t", t]
        garage(*(args + [x["id"]]))
        changed.append(x["id"])
        log("assigned node %s: zone=%s capacity=%d tags=%s"
            % (x["id"][:16], zone, capacity, ",".join(tags) or "-"))

    if not changed:
        if layout.get("stagedRoleChanges"):
            log("layout v%d already has every node with the declared role; leaving "
                "%d staged change(s) made by someone else unapplied"
                % (layout["version"], len(layout["stagedRoleChanges"])))
        else:
            log("layout v%d is already applied as declared, unchanged" % layout["version"])
        return

    new_version = int(layout["version"]) + 1
    out = garage("layout", "apply", "--version", str(new_version))
    for line in out.splitlines():
        if line.strip():
            log("  " + line)
    log("layout v%d applied" % new_version)


# --- 3. Buckets -------------------------------------------------------------------

def bucket_info(name):
    try:
        return api("GetBucketInfo", {"globalAlias": name})
    except CliError as e:
        if "NoSuchBucket" in str(e):
            return None
        raise


def ensure_buckets():
    ids = {}
    for name in CFG["buckets"]:
        info = bucket_info(name)
        if info:
            log("bucket %s exists, unchanged" % name)
        else:
            garage("bucket", "create", name)
            info = bucket_info(name)
            if not info:
                die("bucket %s was created but cannot be read back" % name)
            log("bucket %s created" % name)
        ids[name] = info["id"]
    return ids


# --- 4. Keys ----------------------------------------------------------------------

def read_secret_file(key_name, field):
    path = os.path.join(KEYS_DIR, key_name, field)
    try:
        with open(path, encoding="utf-8") as fh:
            return fh.read().strip()
    except OSError as e:
        die("cannot read %s for key %s: %s" % (field, key_name, e.strerror))


def key_info(key_id):
    try:
        return api("GetKeyInfo", {"id": key_id, "showSecretKey": True})
    except CliError as e:
        if "NoSuchAccessKey" in str(e):
            return None
        raise


def ensure_keys(bucket_ids):
    for k in CFG["keys"]:
        name = k["name"]
        key_id = read_secret_file(name, "AWS_ACCESS_KEY_ID")
        secret = read_secret_file(name, "AWS_SECRET_ACCESS_KEY")
        label = "%s (%s)" % (name, key_id)

        info = key_info(key_id)
        if info is None:
            try:
                api("ImportKey", {"accessKeyId": key_id, "secretAccessKey": secret, "name": name})
            except CliError as e:
                if "KeyAlreadyExists" in str(e):
                    die("key %s was deleted in Garage and Garage will not bring a "
                        "deleted key id back. Delete the Secret %s and upgrade the "
                        "release; the chart generates a new key." % (label, k["secret"]))
                raise
            info = key_info(key_id)
            log("key %s imported" % label)
        else:
            # The Secret is what consumers sign with. If Garage holds a
            # different secret for this id, every request they make is a 403.
            if info.get("secretAccessKey") and info["secretAccessKey"] != secret:
                die("key %s exists in Garage with a different secret than the "
                    "Secret %s holds. Not changing either; fix it by hand."
                    % (label, k["secret"]))
            log("key %s exists, credentials match its Secret" % label)

        have = {b["id"]: b.get("permissions") or {} for b in info.get("buckets") or []}
        for b in k["buckets"]:
            cur = have.get(bucket_ids[b["name"]], {})
            allow = [p for p in ("read", "write", "owner") if b[p] and not cur.get(p)]
            deny = [p for p in ("read", "write", "owner") if not b[p] and cur.get(p)]
            if allow:
                garage(*(["bucket", "allow"] + ["--" + p for p in allow] + [b["name"], "--key", key_id]))
            if deny:
                garage(*(["bucket", "deny"] + ["--" + p for p in deny] + [b["name"], "--key", key_id]))
            if allow or deny:
                log("key %s on bucket %s: granted %s, revoked %s"
                    % (name, b["name"], ",".join(allow) or "-", ",".join(deny) or "-"))
            else:
                log("key %s on bucket %s: permissions already as declared" % (name, b["name"]))


def main():
    if not os.environ.get("GARAGE_RPC_SECRET", "").strip():
        die("GARAGE_RPC_SECRET is empty")
    log("bootstrapping Garage %s in namespace %s: %d node(s), %d bucket(s), %d key(s)"
        % (CFG["fullname"], CFG["namespace"], int(CFG["nodes"]),
           len(CFG["buckets"]), len(CFG["keys"])))
    nodes = wait_for_nodes()
    ensure_layout(nodes)
    # Writes to the bucket and key tables need a write quorum for every
    # partition. "healthy" and "degraded" both have it; "degraded" means a
    # node that holds a role is unreachable, typically one whose volume was
    # lost and replaced by a new node id. Replacing it in the layout is the
    # operator's call (docs/operations.md), never this Job's.
    def quorum():
        h = api("GetClusterHealth")
        return h if h.get("status") in ("healthy", "degraded") else None
    health = until("a write quorum on every partition", quorum)
    if health["status"] == "degraded":
        log("WARNING: cluster is degraded: %d of %d storage nodes reachable. A node in "
            "the layout is down or was replaced; see docs/operations.md."
            % (health.get("storageNodesUp", 0), health.get("storageNodes", 0)))
    ids = ensure_buckets()
    ensure_keys(ids)
    log("done")


if __name__ == "__main__":
    try:
        main()
    except CliError as e:
        die("garage CLI: %s" % e)
