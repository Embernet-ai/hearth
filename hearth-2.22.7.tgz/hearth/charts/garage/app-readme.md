# Garage

S3-compatible object storage for applications on this cluster.

Garage is an open-source object store from Deuxfleurs. It speaks the Amazon S3 API, so any application that uses an S3 SDK, the AWS CLI, or rclone can store files in it. With three nodes it keeps three copies of every object and keeps serving reads and writes when one node fails.

## What you get

- Garage v2.4.1, installed with Garage's official Helm chart.
- An automatic setup Job after every install and upgrade: it connects the nodes, applies the storage layout, creates the buckets you declare, and issues the access keys you declare.
- One Secret per access key, named `<release>-garage-key-<name>`, holding the credentials, endpoint, region, and bucket. Applications read it with `envFrom`.
- Generated secrets that stay the same across upgrades, and pods that meet the Kubernetes restricted security profile.

## Choosing a mode

- **Single node** (default): one node, one copy of each object. For edge sites, labs, and data you back up elsewhere.
- **Three nodes**: set Garage nodes to 3 and replication factor to 3. Three copies, one per node. For production data on a cluster with at least three machines.

The replication factor cannot be changed after install.

## Buckets and keys

Declare them in the YAML values:

```yaml
buckets:
  - name: my-app-files
keys:
  - name: my-app
    buckets:
      - name: my-app-files
        read: true
        write: true
```

Clients must use path-style addressing and sign requests for the region in the Secret (`garage` by default).

## More

Full documentation, including backups and node recovery: https://github.com/Embernet-ai/garage
