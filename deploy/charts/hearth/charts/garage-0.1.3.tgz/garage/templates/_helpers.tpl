{{/*
Everything this chart defines is prefixed "embernet-garage." because the
vendored upstream chart is also named garage and Helm's named templates are
global across a chart and its subcharts. A "garage.fullname" here would
silently replace upstream's.
*/}}

{{/*
The name upstream gives its StatefulSet and main Service, asked of upstream's
own "garage.fullname" with the context its templates see, so this chart can
never disagree with it.
*/}}
{{- define "embernet-garage.upstreamFullname" -}}
{{- include "garage.fullname" (dict "Values" .Values.garage "Release" .Release "Chart" (dict "Name" "garage")) -}}
{{- end }}

{{/* The bootstrap Job and its ConfigMap: <fullname>-bootstrap. */}}
{{- define "embernet-garage.bootstrapName" -}}
{{- printf "%s-bootstrap" (include "embernet-garage.upstreamFullname" .) | trunc 63 | trimSuffix "-" -}}
{{- end }}

{{/* Upstream's StatefulSet replica count, which is the number of Garage nodes. */}}
{{- define "embernet-garage.nodeCount" -}}
{{- int .Values.garage.deployment.replicaCount -}}
{{- end }}

{{- define "embernet-garage.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Labels for what this chart renders. app.kubernetes.io/name is deliberately not
"garage": upstream's Services select on name=garage plus the instance, and a
bootstrap pod carrying both would be added to the S3 Service's endpoints.
*/}}
{{- define "embernet-garage.labels" -}}
helm.sh/chart: {{ include "embernet-garage.chart" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/part-of: garage
{{- with .Values.tenantLabels }}
{{ toYaml . }}
{{- end }}
{{- end }}

{{/*
The release's RPC secret, which the bootstrap Job hands to the garage CLI as
GARAGE_RPC_SECRET. Asked of upstream's own "garage.rpcSecretName", so it
follows garage.garage.existingRpcSecret too. The key is upstream's, rpcSecret.
*/}}
{{- define "embernet-garage.rpcSecretName" -}}
{{- include "garage.rpcSecretName" (dict "Values" .Values.garage "Release" .Release "Chart" (dict "Name" "garage")) -}}
{{- end }}

{{/* The garage image the nodes run, which also supplies the Job's CLI. */}}
{{- define "embernet-garage.image" -}}
{{- printf "%s:%s" .Values.garage.image.repository (.Values.garage.image.tag | default .Chart.AppVersion) -}}
{{- end }}

{{/* Name of the Secret holding one access key. Argument: (list $ keyName). */}}
{{- define "embernet-garage.keySecretName" -}}
{{- $root := index . 0 -}}
{{- printf "%s-garage-key-%s" $root.Release.Name (index . 1) | trunc 253 -}}
{{- end }}

{{/* In-cluster S3 endpoint, through upstream's main Service. */}}
{{- define "embernet-garage.s3Endpoint" -}}
{{- printf "http://%s.%s.svc.%s:%v" (include "embernet-garage.upstreamFullname" .) .Release.Namespace .Values.clusterDomain .Values.garage.service.s3.api.port -}}
{{- end }}

{{/*
32 bytes of randomness as 64 hex characters. randAlphaNum draws from
crypto/rand; hashing it gives a fixed alphabet and length.
*/}}
{{- define "embernet-garage.randHex64" -}}
{{- randAlphaNum 64 | sha256sum -}}
{{- end }}

{{/*
Refuse configurations this chart cannot bootstrap safely. Each one installs
without complaint and then fails somewhere much harder to see.
*/}}
{{- define "embernet-garage.validate" -}}
{{- $g := .Values.garage -}}
{{- if $g.garage.singleNode -}}
{{- fail "garage.garage.singleNode must stay false. It starts Garage with --single-node, which refuses to start once the layout version passes 1, and the bootstrap Job manages the layout. For one node set garage.deployment.replicaCount=1 and garage.garage.replicationFactor=\"1\" (the defaults)." -}}
{{- end -}}
{{- if ne (toString $g.deployment.kind) "StatefulSet" -}}
{{- fail "garage.deployment.kind must be StatefulSet. Upstream's DaemonSet mode stores data on hostPath volumes, which this chart does not allow." -}}
{{- end -}}
{{- if or $g.garage.garageTomlString $g.garage.existingConfigMap -}}
{{- fail "garage.garage.garageTomlString and garage.garage.existingConfigMap are not supported here: the bootstrap Job finds the nodes through the Kubernetes discovery and RPC settings in upstream's generated garage.toml." -}}
{{- end -}}
{{- if kindIs "slice" $g.environment -}}
{{- range $g.environment -}}
{{- if and (kindIs "map" .) (hasPrefix "GARAGE_ADMIN_TOKEN" (toString .name)) -}}
{{- fail "garage.environment must not set GARAGE_ADMIN_TOKEN or GARAGE_ADMIN_TOKEN_FILE. This chart runs Garage with no static admin token: the bootstrap Job uses the garage CLI over RPC, and admin API tokens, if you want any, belong in Garage's own token table (garage admin-token create)." -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- $nodes := int $g.deployment.replicaCount -}}
{{- $rf := int (toString $g.garage.replicationFactor) -}}
{{- if lt $nodes 1 -}}
{{- fail "garage.deployment.replicaCount must be at least 1." -}}
{{- end -}}
{{- if or (lt $rf 1) (gt $rf $nodes) -}}
{{- fail (printf "garage.garage.replicationFactor (%d) must be between 1 and garage.deployment.replicaCount (%d). Garage cannot place more copies than it has nodes." $rf $nodes) -}}
{{- end -}}
{{- if and (not .Values.bootstrap.enabled) (or .Values.buckets .Values.keys) -}}
{{- fail "buckets and keys are created by the bootstrap Job, and bootstrap.enabled is false. Enable it, or empty buckets and keys and manage them by hand." -}}
{{- end -}}
{{- $bucketNames := list -}}
{{- range .Values.buckets -}}
{{- if not (regexMatch "^[a-z0-9][a-z0-9.-]{1,61}[a-z0-9]$" (toString .name)) -}}
{{- fail (printf "bucket name %q is not a valid S3 bucket name (3 to 63 characters: lowercase letters, digits, dots, hyphens; starts and ends with a letter or digit)." (toString .name)) -}}
{{- end -}}
{{- if has .name $bucketNames -}}
{{- fail (printf "bucket %q is listed twice in buckets." .name) -}}
{{- end -}}
{{- $bucketNames = append $bucketNames .name -}}
{{- end -}}
{{- $keyNames := list -}}
{{- range .Values.keys -}}
{{- $k := . -}}
{{- if not (regexMatch "^[a-z0-9]([a-z0-9-]{0,38}[a-z0-9])?$" (toString $k.name)) -}}
{{- fail (printf "key name %q must be a lowercase DNS label of at most 40 characters (letters, digits, hyphens). It becomes part of the Secret <release>-garage-key-<name>." (toString $k.name)) -}}
{{- end -}}
{{- if has $k.name $keyNames -}}
{{- fail (printf "key %q is listed twice in keys." $k.name) -}}
{{- end -}}
{{- $keyNames = append $keyNames $k.name -}}
{{- if not $k.buckets -}}
{{- fail (printf "key %q lists no buckets. Give it at least one; the first becomes S3_BUCKET in its Secret." $k.name) -}}
{{- end -}}
{{- range $k.buckets -}}
{{- if not (has .name $bucketNames) -}}
{{- fail (printf "key %q grants access to bucket %q, which is not in buckets. Declare the bucket so the Job creates it." $k.name (toString .name)) -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- end }}

{{/* The restricted-profile securityContext every Job container uses. */}}
{{- define "embernet-garage.restrictedContainer" -}}
allowPrivilegeEscalation: false
capabilities:
  drop:
    - ALL
readOnlyRootFilesystem: true
runAsNonRoot: true
seccompProfile:
  type: RuntimeDefault
{{- end }}
